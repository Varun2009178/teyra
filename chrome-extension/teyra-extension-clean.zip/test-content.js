console.log('Content script loaded successfully!');
